#include<stdio.h>

int main()
{
	int allocation[100][100],max[100][100],need[100][100],i,j,k,y,p,r,cnt;
	int allocated[100],available[100],safe_state[100];
	
	printf("\n Enter No. of Processes : ");
	scanf("%d",&p);
	
	printf("\n Enter No. of Resources : ");
	scanf("%d",&r);
	
	printf("\n Enter Allocation Data : ");
	for(i=0;i<p;i++)
	{
		printf("\n P%d :",i);
		for(j=0;j<r;j++)
		{
			// printf("\n %c : ",65+j);
			scanf("%d",&allocation[i][j]);
		}
	}	

	printf("\n Enter Max Data : ");
	for(i=0;i<p;i++)
	{
		printf("\n P%d :",i);
		for(j=0;j<r;j++)
		{
			// printf("\n %c : ",65+j);
			scanf("%d",&max[i][j]);
		}
	}
	
	// for Need 
	for(i=0;i<p;i++)
	{
		printf("\n");
		for(j=0;j<r;j++)
		{
			need[i][j] = max[i][j] - allocation[i][j];
		}
	}
	
	printf("\n Enter Available Resources : ");
	for(j=0;j<r;j++)
	{
		// printf("\n %c : ",65+j);
		scanf("%d",&available[j]);
	}

	y=0;
	for(k=0;k<p && y!=p;k++)
	{
		for (i=0;i<p;i++) 
		{
			cnt=0;
			
			for(j=0;j<r;j++) 
			{
				if(need[i][j]<=available[j])
				{
				 	cnt++;
				}
			}
			
			if(cnt==r) 
			{
				safe_state[y++]=i;
				
				for(j=0;j<r;j++)
				{
					available[j]=available[j] + allocated[j];
					need[i][j] = 9999;
				}
			} 
		}
	}
				
	if(y==p)
	{
		printf("\n System is in Safe State : ");
		for(i=0;i<p;i++)
		{
			printf(" P%d ",safe_state[i]);
		}
	}
	else
	{
		printf("\n System is not in Safe State");
	}
	
	return 0;
}
